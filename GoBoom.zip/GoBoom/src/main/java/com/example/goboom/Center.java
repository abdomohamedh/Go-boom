package com.example.goboom;

import javafx.scene.control.Label;

import java.util.*;

class Center {
    public List<Card> cards;
    private LinkedList<Label> labels = new LinkedList<>();
    Map<Card, Player> cardPlayerMap = new HashMap<>();

    public Center() {
        cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        cards.add(card);
    }

    public List<Card> getCards() {
        return cards;
    }

    public Player getWinner() {
        Player winner = null;
        LinkedList<Card> sameSuitedCards = new LinkedList<>();
        for (Card card : this.cards) {
            if (card.getSuit().equalsIgnoreCase(this.cards.get(0).getSuit())) {
                sameSuitedCards.add(card);
            }
        }

        int highestRank = 0;
        for (Card card : sameSuitedCards) {
            if (cardPlayerMap.get(card) != null) {
                if (card.getRankValue() > highestRank) {
                    highestRank = card.getRankValue();
                    winner = cardPlayerMap.get(card);
                }
            }
        }

        return winner;
    }

    public void addCard(Card card, Player player) {
        this.cards.add(card);
        cardPlayerMap.put(card, player);
    }

    public void addLabel(Label label){
        this.labels.add(label);
    }

    public LinkedList<Label> getLabels(){
        return labels;
    }

    public void clear() {
        cards.clear();
    }

}
