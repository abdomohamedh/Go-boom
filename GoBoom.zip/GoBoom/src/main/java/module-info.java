module com.example.goboom {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.goboom to javafx.fxml;
    exports com.example.goboom;
}