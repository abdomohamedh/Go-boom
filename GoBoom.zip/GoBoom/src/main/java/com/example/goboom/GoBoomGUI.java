package com.example.goboom;

import javafx.application.Application;
import javafx.geometry.Dimension2D;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class GoBoomGUI extends Application {

    private Stage stage;
    private static GoBoom game;

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        primaryStage.setTitle("GoBoomGUI");

        Scene primaryScene = createPrimaryScene();
        primaryStage.setScene(primaryScene);

        primaryStage.show();
    }

    private Scene createPrimaryScene() {
        // Load background image
        Image backgroundImage = new Image("file:/Users/abdomohamed/Desktop/ass1/GoBoom/src/main/resources/com/example/Interface.jpg");
        BackgroundSize backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        Background backgroundAll = new Background(background);

        // Create buttons and set their actions
        Button playButton = new Button("Play");
        playButton.setOnAction(e -> stage.setScene(createSecondaryScene()));

        Button resumeButton = new Button("Resume");

        Button exitButton = new Button("Exit");
        exitButton.setOnAction(e -> System.exit(0));

        // Layout buttons vertically
        VBox vbox = new VBox(30, playButton, resumeButton, exitButton);
        vbox.setAlignment(Pos.CENTER);

        // Create root and add background to root
        StackPane root = new StackPane(vbox);
        root.setBackground(backgroundAll);

        return new Scene(root, 600, 400);
    }

    private Scene createSecondaryScene() {
//        Start the game to distribute and set up the players
        game = new GoBoom();
        game.startGame();

        //Create buttons and store them in the list of buttons in the player object
        for(Player player: game.players){
            for(Card card : player.getHand()){
                Button cardButton = createButtonWithName(card.toString().toLowerCase());
                player.addButton(cardButton);
            }
        }

        //Create labels for all the center cards and add them to the labels list in the center object of the game object
        for(Card card: game.center.getCards()){
            Label label = createLabelWithName(card.toString().toLowerCase());
            game.center.addLabel(label);
        }

        Button goBackButton = new Button("Go Back");
        goBackButton.setOnAction(e -> stage.setScene(createPrimaryScene()));

        HBox player1cards = new HBox();
        HBox player3cards = new HBox();
        HBox centreCards = new HBox();
        HBox deckCard = new HBox();

        player1cards.setAlignment(Pos.CENTER);
        player3cards.setAlignment(Pos.CENTER);
        centreCards.setAlignment(Pos.CENTER);
        deckCard.setAlignment(Pos.CENTER_RIGHT);

        VBox player2cards = new VBox();
        VBox player4cards = new VBox();

        player2cards.setAlignment(Pos.CENTER);
        player4cards.setAlignment(Pos.CENTER);

        player1cards.setSpacing(-60);
        player2cards.setSpacing(-100);
        player3cards.setSpacing(-60);
        player4cards.setSpacing(-100);

//        Color the boxes to mark the positions
//        player1cards.setStyle("-fx-background-color: #ff0000");
//        player2cards.setStyle("-fx-background-color: #00ff00");
//        player3cards.setStyle("-fx-background-color: #0000ff");
//        player4cards.setStyle("-fx-background-color: #ffff00");
//        centreCards.setStyle("-fx-background-color: #00ffff");
//        deckCard.setStyle("-fx-background-color: #000000");

        //Put the cards for each player to their respective container
        int playerCounter = 1;
        for(Player player: game.players){
            switch (playerCounter) {
                case 1 -> player1cards.getChildren().setAll(player.getButtons());
                case 2 -> player2cards.getChildren().setAll(player.getButtons());
                case 3 -> player3cards.getChildren().setAll(player.getButtons());
                case 4 -> player4cards.getChildren().setAll(player.getButtons());
            }
            playerCounter +=  1;
        }

        centreCards.getChildren().setAll(game.center.getLabels());

        // Main layout
        BorderPane borderPane = new BorderPane();
        borderPane.setPadding(new Insets(10));

        borderPane.setTop(player1cards);
        borderPane.setBottom(player3cards);
        borderPane.setRight(player2cards);
        borderPane.setLeft(player4cards);
        borderPane.setCenter(centreCards);

        HBox hBoxDeckCard = new HBox(deckCard);
        hBoxDeckCard.setPadding(new Insets(0, 0, 0, 200));
        borderPane.getChildren().add(hBoxDeckCard);


        // Load background image
        Image backgroundImage = new Image("file:/Users/abdomohamed/Desktop/ass1/GoBoom/src/main/resources/com/example/background.jpg");
        BackgroundSize backgroundSize = new BackgroundSize(100, 100, true, true, true, false);
        BackgroundImage background = new BackgroundImage(backgroundImage, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, backgroundSize);
        Background backgroundAll = new Background(background);

        // Position go back button and create root
        StackPane root = new StackPane(borderPane, goBackButton);
        root.setBackground(backgroundAll);
        StackPane.setAlignment(goBackButton, Pos.TOP_RIGHT);
        StackPane.setMargin(goBackButton, new Insets(10, 10, 0, 0));

        return new Scene(root, 1330, 530);
    }
    public static Button createButtonWithName(String name) {
        // Create a button
        Button button = new Button();

        // Load the image
        Image image = new Image("file:/Users/abdomohamed/Desktop/ass1/GoBoom/src/main/resources/com/example/Cards/" + name + ".png");

        // Create an ImageView with the loaded image
        ImageView imageView = new ImageView(image);

        // Set the preferred size for the ImageView
        Dimension2D imageSize = new Dimension2D(100, 130);
        imageView.setFitWidth(imageSize.getWidth());
        imageView.setFitHeight(imageSize.getHeight());
        imageView.setPreserveRatio(true);

        // Set the ImageView as the background of the button
        button.setGraphic(imageView);

        // Set the button's background to transparent
        button.setStyle("-fx-background-color: transparent;");

//        // Add an event listener to the button
        button.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
            game.playGame(name);
        });

        return button;
    }

    public static Label createLabelWithName(String name) {
        // Create a label
        Label label = new Label();

        // Load the image
        Image image = new Image("file:/Users/abdomohamed/Desktop/ass1/GoBoom/src/main/resources/com/example/Cards/" + name + ".png");

        // Create an ImageView with the loaded image
        ImageView imageView = new ImageView(image);

        // Set the preferred size for the ImageView
        Dimension2D imageSize = new Dimension2D(100, 130);
        imageView.setFitWidth(imageSize.getWidth());
        imageView.setFitHeight(imageSize.getHeight());
        imageView.setPreserveRatio(true);

        // Set the ImageView as the background of the label
        label.setGraphic(imageView);

        // Set the label's background to transparent
        label.setStyle("-fx-background-color: transparent;");

        return label;
    }

    public static void main(String[] args) {
        launch(args);
    }
}