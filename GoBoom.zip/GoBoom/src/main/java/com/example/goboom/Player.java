package com.example.goboom;
import javafx.scene.control.Button;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

class Player {
    private final String name;
    private final List<Card> hand;
    private Card leadCard;
    private final LinkedList<Button> cardButtons = new LinkedList<>();
    int score;

    public Player(String name) {
        this.score = 0;
        this.name = name;
        this.hand = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void receiveCard(Card card) {
        hand.add(card);
    }

    public void playCard(Card playedCard) {
        for (Card card: this.hand){
            if(card.getSuit().equalsIgnoreCase(playedCard.getSuit()) && card.getRank().equalsIgnoreCase(playedCard.getRank())){
                leadCard = card;
                this.hand.remove(card);
                break;
            }
        }
    }

    public List<Card> getHand() {
        return hand;
    }

    public Card getLeadCard() {
        return leadCard;
    }

    public boolean canPlayCard(Card card, Card leadCard) {
        if (leadCard == null) {
            return true; // First lead card, any card can be played
        }
        String leadSuit = leadCard.getSuit();
        String leadRank = leadCard.getRank();
        return card.getSuit().equalsIgnoreCase(leadSuit) || card.getRank().equalsIgnoreCase(leadRank);
    }

    public void addButton(Button button){
        this.cardButtons.add(button);
    }

    public LinkedList<Button> getButtons(){
        return cardButtons;
    }

    public void addScore(){

        this.score += 1;
    }
}
