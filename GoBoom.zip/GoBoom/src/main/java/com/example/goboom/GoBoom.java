package com.example.goboom;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class GoBoom {
    Center center;
    Deck deck;
    private List<Integer> scores;
    List<Player> players;
    private int trickPlayed = 1;
    Card leadCard;
    int currentPlayerIndex;

    public GoBoom() {
        deck = new Deck();
        players = new ArrayList<>();
        scores = new ArrayList<>();
        center = new Center();
        currentPlayerIndex = 1;
        startGame();
    }

    public void startGame() {
        deck.initializeDeck();
        deck.shuffleDeck();

        // Create the players
        for (int i = 0; i < 4; i++) {
            players.add(new Player("Player " + (i + 1)));
            scores.add(i, 0);
        }


        dealCards();
        System.out.print("Deck: ");
        leadCard = deck.dealCard();
        center.addCard(leadCard, null);
        setFirstPlayer();

        // Print out the game board
        showGame();

//        playGame();

    }

    private void dealCards() {
        for (Player player : players) {
            for (int i = 0; i <= 6; i++) {
                Card card = deck.dealCard();
                player.receiveCard(card);
            }
        }

    }

    private void setFirstPlayer() {
        switch (leadCard.getRank()) {
            case "A", "5", "9", "K" -> currentPlayerIndex = 0; // Player1
            case "2", "6", "10" -> currentPlayerIndex = 1; // Player2
            case "3", "7", "J" -> currentPlayerIndex = 2; // Player3
            case "4", "8", "Q" -> currentPlayerIndex = 3; // Player4
        }

    }

    private Card getUserCard(String name) {
//        System.out.print("Chose Card -> ");
//        Scanner input = new Scanner(System.in);
        String suit = name.valueOf(name.charAt(0));
        String rank = name.substring(1);

        return new Card(suit, rank);
    }

    public void playGame(String playedCardName) {
        Card playedCard = getUserCard(playedCardName);

        Player currentPlayer = players.get(currentPlayerIndex);

        if (currentPlayer.canPlayCard(playedCard, leadCard)) {

            System.out.println(currentPlayer.getName() + " plays:[ " + playedCard.getSuit() + " "
                    + playedCard.getRank() + "]");
            currentPlayer.playCard(playedCard);

//                Update the center card and player
            center.addCard(playedCard, currentPlayer);
            // Update lead card for next turn
            leadCard = playedCard;

            // Determine the winner of the trick and update currentPlayerIndex accordingly
            currentPlayerIndex = (currentPlayerIndex + 1) % 4;

//                Show the game after every trick is played
            showGame();

//                Check if the trick is finished
            if (trickPlayed > 3) {
                Player winner = center.getWinner();
                System.out.printf("The winner is: %s \n", winner.getName());
                currentPlayerIndex = players.indexOf(winner);
                trickPlayed = 1;
            } else {
                trickPlayed += 1;
            }
        } else {
            System.out.println(
                    currentPlayer.getName() + " cannot play: " + playedCard.getSuit() + " " + playedCard.getRank());
        }
    }

    public void showGame() {
        System.out.println(deck.cards.toString());
        for (Player player : players) {
            System.out.println(player.getName() + ": " + player.getHand().toString() + "| Score: " + player.score);
        }
        System.out.println("Center : " + center.getCards().toString());
        System.out.println("Turn : " + players.get(currentPlayerIndex).getName());
    }

//    public static void main(String[] args) {
//        GoBoom game = new GoBoom();
//        while (!game.players.get(game.currentPlayerIndex).getHand().isEmpty()) {
//            game.playGame();
//        }
//    }
}

