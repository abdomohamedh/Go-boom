package com.example.goboom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Card {
    String suit;
    String rank;
    List<String> stringList = Arrays.asList("2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A");

    public Card(String suit, String rank) {
        this.suit = suit;
        this.rank = rank;
    }

    public String getSuit() {
        return suit;
    }

    public String getRank() {
        return rank;
    }
    public int getRankValue(){
        return stringList.indexOf(this.getRank().toUpperCase());
    }

    public String toString() {
        return rank + suit;
    }
}
